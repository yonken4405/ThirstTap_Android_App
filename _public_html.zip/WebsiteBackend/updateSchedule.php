<?php
// Start session
session_start();

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include database connection file
require_once 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

// Get admin ID and station ID from session
$admin_id = $_SESSION['admin_id'];
$station_id = $_SESSION['station_id'];

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Check if json_decode failed
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input.']);
    exit;
}

// Loop through the received schedule data
foreach ($data as $day => $info) {
    $isClosed = $info['closed'] ? 1 : 0; // 1 for closed, 0 for open
    $openingTime = $info['opening'] ?? null; // Use null if not provided
    $closingTime = $info['closing'] ?? null; // Use null if not provided

    // Check if the schedule for this day already exists for this station
    $stmt_check = $conn->prepare("SELECT station_id FROM station_schedule WHERE station_id = ? AND day_of_week = ?");
    $stmt_check->bind_param("is", $station_id, $day);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        // If it exists, perform an update
        $stmt_update = $conn->prepare("UPDATE station_schedule 
                                        SET 
                                            is_closed = ?, 
                                            opening_time = ?, 
                                            closing_time = ? 
                                        WHERE 
                                            station_id = ? AND day_of_week = ?");
        
        // Check if the statement was prepared correctly
        if (!$stmt_update) {
            echo json_encode(['success' => false, 'message' => 'Database error on schedule update.']);
            exit;
        }

        // Bind parameters
        $stmt_update->bind_param("issis", $isClosed, $openingTime, $closingTime, $station_id, $day);

        // Execute the statement for schedule update
        if (!$stmt_update->execute()) {
            echo json_encode(['success' => false, 'message' => 'Error updating station schedule.']);
            exit;
        }
        
        $stmt_update->close();
    } else {
        // If it does not exist, insert a new record
        $stmt_insert = $conn->prepare("INSERT INTO station_schedule (station_id, day_of_week, is_closed, opening_time, closing_time) 
                                        VALUES (?, ?, ?, ?, ?)");

        // Check if the statement was prepared correctly
        if (!$stmt_insert) {
            echo json_encode(['success' => false, 'message' => 'Database error on schedule insert.']);
            exit;
        }

        // Bind parameters
        $stmt_insert->bind_param("isiss", $station_id, $day, $isClosed, $openingTime, $closingTime);

        // Execute the statement for schedule insert
        if (!$stmt_insert->execute()) {
            echo json_encode(['success' => false, 'message' => 'Error inserting station schedule.']);
            exit;
        }

        $stmt_insert->close();
    }

    $stmt_check->close();
}

// Close the database connection
$conn->close();

// Return success message
echo json_encode(['success' => true, 'message' => 'Station schedules updated successfully.']);
?>
