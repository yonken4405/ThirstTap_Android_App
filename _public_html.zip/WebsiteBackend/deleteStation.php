<?php
require 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get POST data
$stationId = (int) $_POST['station_id'];

// Begin transaction to ensure atomicity
$conn->begin_transaction();

$response = [];

// Delete from station_options
$optionStmt = $conn->prepare("DELETE FROM station_options WHERE station_id = ?");
if (!$optionStmt) {
    $response['success'] = false;
    $response['message'] = 'Prepare failed for station_options: ' . $conn->error;
    $conn->rollback(); // Rollback transaction if failure occurs
    echo json_encode($response);
    exit;
}
$optionStmt->bind_param("i", $stationId);
if (!$optionStmt->execute()) {
    $response['success'] = false;
    $response['message'] = 'Execution failed for station_options: ' . $optionStmt->error;
    $conn->rollback();
    echo json_encode($response);
    exit;
}
$optionStmt->close();

// Delete from station_prices
$priceStmt = $conn->prepare("DELETE FROM station_prices WHERE station_id = ?");
if (!$priceStmt) {
    $response['success'] = false;
    $response['message'] = 'Prepare failed for station_prices: ' . $conn->error;
    $conn->rollback();
    echo json_encode($response);
    exit;
}
$priceStmt->bind_param("i", $stationId);
if (!$priceStmt->execute()) {
    $response['success'] = false;
    $response['message'] = 'Execution failed for station_prices: ' . $priceStmt->error;
    $conn->rollback();
    echo json_encode($response);
    exit;
}
$priceStmt->close();

// Delete from station_schedule
$scheduleStmt = $conn->prepare("DELETE FROM station_schedule WHERE station_id = ?");
if (!$scheduleStmt) {
    $response['success'] = false;
    $response['message'] = 'Prepare failed for station_schedule: ' . $conn->error;
    $conn->rollback();
    echo json_encode($response);
    exit;
}
$scheduleStmt->bind_param("i", $stationId);
if (!$scheduleStmt->execute()) {
    $response['success'] = false;
    $response['message'] = 'Execution failed for station_schedule: ' . $scheduleStmt->error;
    $conn->rollback();
    echo json_encode($response);
    exit;
}
$scheduleStmt->close();

// Delete from stations (main table)
$stationStmt = $conn->prepare("DELETE FROM stations WHERE station_id = ?");
if (!$stationStmt) {
    $response['success'] = false;
    $response['message'] = 'Prepare failed for stations: ' . $conn->error;
    $conn->rollback();
    echo json_encode($response);
    exit;
}
$stationStmt->bind_param("i", $stationId);
if ($stationStmt->execute()) {
    // Commit the transaction after all deletions succeed
    $conn->commit();
    $response['success'] = true;
    $response['message'] = 'Station and related data deleted successfully.';
} else {
    $response['success'] = false;
    $response['message'] = 'Execution failed for stations: ' . $stationStmt->error;
    $conn->rollback();
}

$stationStmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json'); // Ensure the correct content type is set
echo json_encode($response);
exit;

?>
