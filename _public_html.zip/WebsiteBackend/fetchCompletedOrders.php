<?php
session_start(); // Start the session
require 'db.php'; // Include your database connection file

// Default filter
$filter = 'monthly'; // Change as needed
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filter = $_POST['date-filter'];
}

// Ensure that the station_id is set in the session
$station_id = isset($_SESSION['station_id']) ? $_SESSION['station_id'] : null;

// Get current date in Philippine Time (PHT)
$timezone = new DateTimeZone('Asia/Manila'); // Define PHT timezone
$dateTime = new DateTime('now', $timezone); // Get the current time in PHT
$currentDatePHT = $dateTime->format('Y-m-d'); // Format as 'Y-m-d'

// Get the start date for 7-day interval (6 days before today)
$startDate = (new DateTime('now', $timezone))->modify('-6 days')->format('Y-m-d');

// Prepare SQL query to fetch completed orders
$sql = "SELECT orderid, total_price, delivery_date FROM orders WHERE station_id = ? AND status = 'Completed'";

// Add date filter to the SQL query with PHT timezone
switch ($filter) {
    case 'today':
        $sql .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = ?";
        break;
    case 'weekly':
        $sql .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) BETWEEN ? AND ?";
        break;
    case 'monthly':
        $sql .= " AND MONTH(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = MONTH(?) 
                  AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        break;
    case 'yearly':
        $sql .= " AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        break;
}

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameters based on the filter
switch ($filter) {
    case 'today':
        $stmt->bind_param("is", $station_id, $currentDatePHT);
        break;
    case 'weekly':
        $stmt->bind_param("iss", $station_id, $startDate, $currentDatePHT); // 3 parameters: station_id, startDate, currentDatePHT
        break;
    case 'monthly':
        $stmt->bind_param("iss", $station_id, $currentDatePHT, $currentDatePHT); // 3 parameters: station_id, currentDatePHT for month, currentDatePHT for year
        break;
    case 'yearly':
        $stmt->bind_param("is", $station_id, $currentDatePHT); // 2 parameters: station_id, currentDatePHT for year
        break;
}

// Execute the statement
$stmt->execute();

// Fetch the result
$result = $stmt->get_result();
$completedOrders = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Format the delivery date to a more readable format (e.g., 'F j, Y' for 'October 7, 2024')
        $formattedDate = date('F j, Y', strtotime($row['delivery_date']));
        $completedOrders[] = [
            'orderid' => $row['orderid'],
            'total_price' => $row['total_price'],
            'delivery_date' => $formattedDate // Use the formatted date here
        ]; // Store completed orders with formatted date
    }
}
$stmt->close(); // Close the prepared statement
$conn->close(); // Close the database connection

// Return completed orders as JSON
header('Content-Type: application/json');
echo json_encode($completedOrders);

?>
