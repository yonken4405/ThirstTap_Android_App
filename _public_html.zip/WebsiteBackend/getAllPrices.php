<?php
// Start the session
session_start();

// Include database configuration
require 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['station_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    exit();
}

// Get the station_id from the session
$station_id = $_SESSION['station_id'];

// Prepare and execute the SQL statement for all water types including new container price
$sql = "SELECT water_type, price_5gallon, price_slim_5gallon, price_slim_2_5gallon, new_container_price 
        FROM station_prices 
        WHERE station_id = ?"; // Add a condition to filter by station_id

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $station_id); // Bind the station_id as an integer
$stmt->execute();
$result = $stmt->get_result(); // Get the result set from the prepared statement

// Initialize the response array
$response = [
    'success' => true,
    'data' => [],
];

// Fetch the prices for each water type
while ($row = $result->fetch_assoc()) {
    $waterType = ucfirst(strtolower($row['water_type'])); // Normalize water type
    $response['data'][$waterType] = [
        'prices' => [
            'round-5gal' => $row['price_5gallon'],
            'slim-5gal' => $row['price_slim_5gallon'],
            'slim-2-5gal' => $row['price_slim_2_5gallon'],
            'new-container' => $row['new_container_price'], // Include new container price
        ],
    ];
}

// Debugging: Log the fetched data
error_log(print_r($response['data'], true)); // Log the data to the server error log for debugging

// If no data is found, set success to false
if (empty($response['data'])) {
    $response['success'] = false;
    $response['message'] = 'No prices found for any water types for the specified station.';
}

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);

// Close the connection
$stmt->close(); // Close the prepared statement
$conn->close();
?>
