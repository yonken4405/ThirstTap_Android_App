<?php
require 'db.php'; // Include your database connection file

// Pagination variables
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Get the current page from the query parameter
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10; // Set the number of users per page
$offset = ($page - 1) * $limit; // Calculate the offset for the SQL query

// Fetch total number of users for pagination
$totalQuery = "SELECT COUNT(*) as total FROM user_data"; // Query to count total users
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalUsers = $totalRow['total']; // Get total users count
$totalPages = ceil($totalUsers / $limit); // Calculate total pages

// Fetching user details with pagination
$query = "SELECT userid, name, phone_num, email FROM user_data LIMIT $limit OFFSET $offset"; // Selecting required fields with limit and offset
$result = $conn->query($query);

// Prepare an array to hold the user data
$users = [];

if ($result->num_rows > 0) {
    // Fetch all results into the $users array
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}

// Close the database connection
$conn->close();

// Return the user data and total pages as a JSON object
header('Content-Type: application/json'); // Set header for JSON response
echo json_encode(['users' => $users, 'totalPages' => $totalPages]); // Include total pages in the response
?>
