<?php
// Start session
session_start();

// Include database connection file
require_once 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

// Get admin ID from session
$admin_id = $_SESSION['admin_id'];
$station_id = $_SESSION['station_id'];

// Get the raw POST data
$data = json_decode(file_get_contents("php://input"), true);

// Get updated profile information from the request
$adminName = $data['admin_name'] ?? '';
$adminEmail = $data['admin_mail'] ?? '';
$admin_contact_number = $data['admin_contact_number'] ?? '';
$station_name = $data['station_name'] ?? '';
$station_address = $data['station_address'] ?? '';
$station_contact = $data['station_contact'] ?? '';
$station_email = $data['station_email'] ?? '';

// Prepare and bind the SQL statements

// Update admin details
$stmt_admin = $conn->prepare("
    UPDATE admins
    SET admin_name = ?, contact_number = ?, station_name = ?
    WHERE admin_id = ?
");

// Check if the statement was prepared correctly
if (!$stmt_admin) {
    echo json_encode(['success' => false, 'message' => 'Database error on admin update.']);
    exit;
}

// Bind parameters
$stmt_admin->bind_param("sssi", $adminName, $admin_contact_number, $station_name, $admin_id);

// Execute the statement for admin update
if (!$stmt_admin->execute()) {
    echo json_encode(['success' => false, 'message' => 'Error updating admin profile.']);
    exit;
}

// Update station details
$stmt_station = $conn->prepare("
    UPDATE stations
    SET name = ?, station_address = ?, contact_number = ?, email = ?
    WHERE station_id = ?
");

// Check if the statement was prepared correctly
if (!$stmt_station) {
    echo json_encode(['success' => false, 'message' => 'Database error on station update.']);
    exit;
}

// Bind parameters
$stmt_station->bind_param("ssssi", $station_name, $station_address, $station_contact, $station_email, $station_id);

// Execute the statement for station update
if (!$stmt_station->execute()) {
    echo json_encode(['success' => false, 'message' => 'Error updating station profile.']);
    exit;
}

// Close statements and connection
$stmt_admin->close();
$stmt_station->close();
$conn->close();

// Return success message
echo json_encode(['success' => true, 'message' => 'Profiles updated successfully.']);
?>
