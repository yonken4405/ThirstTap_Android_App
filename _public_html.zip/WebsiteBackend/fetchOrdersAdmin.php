<?php
header('Content-Type: application/json');
require 'db.php';
session_start(); // Start the session to access session variables

$status = isset($_GET['status']) ? $_GET['status'] : 'all'; // Get status from query parameters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$station_id = $_SESSION['station_id']; // Get the station ID from the session

$sql = "SELECT orderid, delivery_date, status FROM orders WHERE station_id = ?"; // Only fetch orders for the specific station

if ($status != 'all') {
    $sql .= " AND status = ?"; // Filter by status if not 'all'
}

if (!empty($search)) {
    // Add search condition, using parameterized queries is highly recommended to prevent SQL injection
    $sql .= " AND orderid LIKE ?";
}

$stmt = $conn->prepare($sql);
$params = [$station_id]; // First parameter is the station ID

if ($status != 'all') {
    $params[] = $status; // Add status if applicable
}
if (!empty($search)) {
    $params[] = "%$search%"; // Add search term
}

$stmt->bind_param(str_repeat('s', count($params)), ...$params); // Bind parameters
$stmt->execute();
$result = $stmt->get_result();

$orders = array();

while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

echo json_encode($orders);
?>
