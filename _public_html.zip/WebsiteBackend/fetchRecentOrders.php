<?php
header('Content-Type: application/json');
require 'db.php';
session_start();

$station_id = $_SESSION['station_id'];

// Get today's date in Philippine Time (PHT)
$timezone = new DateTimeZone('Asia/Manila'); // Define the timezone
$dateTime = new DateTime('now', new DateTimeZone('UTC')); // Get current time in UTC
$dateTime->setTimezone($timezone); // Set timezone to PHT
$today = $dateTime->format('Y-m-d'); // Format date as 'Y-m-d'

// Prepare the SQL statement to fetch today's orders
$sql = "SELECT orderid, delivery_date, status FROM orders WHERE station_id = ? AND delivery_date = ?";
$sql .= " ORDER BY orderid DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $station_id, $today);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

echo json_encode($orders);
?>
