<?php
require 'db.php'; // Assuming this file contains the mysqli connection in $conn

// Get data from POST request
$station_id = $_POST['station_id']; // Make sure this is 'station_id'
$adminname = $_POST['adminname'];
$contactnum = $_POST['contactnum'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password for security
$role = $_POST['role'];

// Validate the station ID
$station_id_query = "SELECT name FROM stations WHERE station_id = '$station_id'"; // Directly using the variable in the query
$result = mysqli_query($conn, $station_id_query);

if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Database query failed.']);
    exit();
}

if (mysqli_num_rows($result) == 0) {
    echo json_encode(['success' => false, 'message' => 'Station not found']);
    exit();
}

// Fetch the station name
$station_row = mysqli_fetch_assoc($result);
$station_name = $station_row['name']; // Get the station name

// Insert the new admin into the admins table
$insert_query = "INSERT INTO admins (station_id, admin_name, contact_number, email, password, role, station_name) VALUES ('$station_id', '$adminname', '$contactnum', '$email', '$password', '$role', '$station_name')";

if (mysqli_query($conn, $insert_query)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to add admin: ' . mysqli_error($conn)]);
}

// Close the database connection
mysqli_close($conn);
?>
