<?php
require 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Decode the incoming JSON input
$data = json_decode(file_get_contents('php://input'), true);

// Check if the data was successfully decoded
if ($data === null) {
    echo json_encode(['success' => false, 'message' => 'Invalid input format.']);
    exit;
}

// Get data from the decoded JSON
$stationName = $data['name'] ?? null;  // Updated key
$address = $data['address'] ?? null;    // Updated key
$latitude = $data['latitude'] ?? null;  // Updated key
$longitude = $data['longitude'] ?? null; // Updated key
$contactNum = $data['contact_number'] ?? null; // Updated key
$email = $data['email'] ?? null;         // Updated key

// Check for required fields
$requiredFields = [
    'name' => $stationName,
    'address' => $address,
    'contact_number' => $contactNum,
    'email' => $email,
];

$errorMessages = [];
foreach ($requiredFields as $field => $value) {
    if (empty($value)) {
        $errorMessages[] = ucfirst(str_replace('_', ' ', $field)) . ' is required.';
    }
}

// Validate latitude and longitude
if (!isset($latitude) || !is_numeric($latitude) || !preg_match('/^-?([1-8]?[0-9](\.[0-9]+)?|90(\.0+)?)$/', $latitude)) {
    $errorMessages[] = 'Latitude must be a number between -90 and 90.';
}
if (!isset($longitude) || !is_numeric($longitude) || !preg_match('/^-?(180(\.0+)?|([1-9]?[0-9]|1[0-7][0-9])(\.[0-9]+)?)$/', $longitude)) {
    $errorMessages[] = 'Longitude must be a number between -180 and 180.';
}

// Return specific error messages if any
if (!empty($errorMessages)) {
    echo json_encode(['success' => false, 'message' => implode(' ', $errorMessages)]);
    exit;
}

// Prepare and execute the statement to insert into stations table
$stmt = $conn->prepare("INSERT INTO stations (name, station_address, latitude, longitude, contact_number, email) VALUES (?, ?, ?, ?, ?, ?)");
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
    exit;
}

$stmt->bind_param("ssddss", $stationName, $address, $latitude, $longitude, $contactNum, $email);

$response = [];
if ($stmt->execute()) {
    // Get the last inserted station ID
    $stationId = $conn->insert_id;

    // Prepare water types to insert into station_options and station_prices tables
    $waterTypes = ['Spring', 'Alkaline', 'Mineral', 'Purified'];

    // Prepare statement to insert into station_options
    $optionStmt = $conn->prepare("INSERT INTO station_options (station_id, water_type) VALUES (?, ?)");
    if (!$optionStmt) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed for station_options: ' . $conn->error]);
        exit;
    }

    // Prepare statement to insert into station_prices
    $priceStmt = $conn->prepare("INSERT INTO station_prices (station_id, water_type) VALUES (?, ?)");
    if (!$priceStmt) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed for station_prices: ' . $conn->error]);
        exit;
    }

    // Insert each water type with the station ID into both station_options and station_prices
    foreach ($waterTypes as $waterType) {
        // Insert into station_options
        $optionStmt->bind_param("is", $stationId, $waterType);
        if (!$optionStmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Execution failed for station_options: ' . $optionStmt->error]);
            exit;
        }

        // Insert into station_prices
        $priceStmt->bind_param("is", $stationId, $waterType);
        if (!$priceStmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Execution failed for station_prices: ' . $priceStmt->error]);
            exit;
        }
    }

    // Close option and price statements
    $optionStmt->close();
    $priceStmt->close();

    // Prepare days of the week to insert into station_schedule
    $daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

    // Prepare statement to insert into station_schedule
    $scheduleStmt = $conn->prepare("INSERT INTO station_schedule (station_id, day_of_week) VALUES (?, ?)");
    if (!$scheduleStmt) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed for station_schedule: ' . $conn->error]);
        exit;
    }

    // Insert each day of the week with the station ID into station_schedule
    foreach ($daysOfWeek as $day) {
        $scheduleStmt->bind_param("is", $stationId, $day);
        if (!$scheduleStmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Execution failed for station_schedule: ' . $scheduleStmt->error]);
            exit;
        }
    }

    // Close the schedule statement
    $scheduleStmt->close();

    // If everything is successful
    $response['success'] = true;
    $response['message'] = 'Station, options, prices, and schedule added successfully.';

} else {
    $response['success'] = false;
    $response['message'] = 'Execution failed: ' . $stmt->error;
}

// Close the first statement and connection
$stmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json'); // Ensure the correct content type is set
echo json_encode($response);
exit;
