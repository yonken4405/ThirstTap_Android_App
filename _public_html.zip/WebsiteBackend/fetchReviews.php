<?php
require 'db.php';

header('Content-Type: application/json');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log the incoming parameters
file_put_contents('debug.log', print_r($_GET, true), FILE_APPEND);

// Default values for pagination
$reviews_per_page = isset($_GET['limit']) ? (int)$_GET['limit'] : 10; // Number of reviews per page (default 10)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page (default is page 1)

// Calculate the offset
$offset = ($page - 1) * $reviews_per_page;

// Fetch total reviews and average rating
$total_reviews_sql = "SELECT COUNT(*) as total_reviews, AVG(rating) as average_rating FROM feedback";
$result = $conn->query($total_reviews_sql);
if (!$result) {
    die(json_encode(['error' => 'Database query failed: ' . $conn->error]));
}

$row = $result->fetch_assoc();
$total_reviews = $row['total_reviews'];
$average_rating = number_format($row['average_rating'], 1);

// Log total reviews and average rating
file_put_contents('debug.log', "Total Reviews: $total_reviews, Average Rating: $average_rating\n", FILE_APPEND);

// Fetch rating breakdown
$rating_breakdown = [];
for ($i = 5; $i >= 1; $i--) {
    $sql = "SELECT COUNT(*) as count FROM feedback WHERE rating = $i";
    $result = $conn->query($sql);
    if (!$result) {
        die(json_encode(['error' => 'Database query failed: ' . $conn->error]));
    }
    $row = $result->fetch_assoc();
    $rating_breakdown[$i] = $row['count'];
}

// Fetch reviews with customer names, applying the limit and offset for pagination and filtering
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all'; // Get filter from the request
$filter_condition = "";

// Add condition for specific rating
if ($filter !== 'all') {
    $filter_condition = "WHERE feedback.rating = $filter"; 
}

// Fetch the reviews
$reviews_sql = "
    SELECT feedback.feedback, feedback.rating, feedback.created_at, user_data.name
    FROM feedback
    JOIN user_data ON feedback.userid = user_data.userid
    $filter_condition
    ORDER BY feedback.created_at DESC
    LIMIT $reviews_per_page OFFSET $offset
";

// Log the SQL query
file_put_contents('debug.log', $reviews_sql . "\n", FILE_APPEND);

$reviews_result = $conn->query($reviews_sql);
if (!$reviews_result) {
    die(json_encode(['error' => 'Database query failed: ' . $conn->error]));
}

// Check if any reviews were fetched
$reviews = [];
while ($review = $reviews_result->fetch_assoc()) {
    $reviews[] = [
        'customer_name' => htmlspecialchars($review['name']), // Fetch customer name from user_data
        'rating' => (int)$review['rating'],
        'feedback' => htmlspecialchars($review['feedback']), // Sanitize output
        'created_at' => date('m-d-Y', strtotime($review['created_at']))
    ];
}

// Log the number of reviews fetched
file_put_contents('debug.log', "Number of Reviews Fetched: " . count($reviews) . "\n", FILE_APPEND);

// Calculate total pages
$total_pages = ceil($total_reviews / $reviews_per_page);

// Return data as JSON
echo json_encode([
    'total_reviews' => $total_reviews,
    'average_rating' => $average_rating,
    'rating_breakdown' => $rating_breakdown,
    'reviews' => $reviews,
    'current_page' => $page,
    'total_pages' => $total_pages
]);

$conn->close();
?>
