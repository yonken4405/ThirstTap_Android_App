<?php
session_start(); // Start the session to access session variables

require 'db.php';

// Check if admin_id is set in session
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Admin not logged in.']);
    exit();
}

// Use the admin_id from the session for fetching data
$admin_id = $_SESSION['admin_id'];

// Fetch admin and station data using the admin_id
$sql = "SELECT a.admin_name, a.email, a.role, a.contact_number, 
               s.name AS station_name, s.station_address, 
               s.contact_number AS station_contact, s.email AS station_email
        FROM admins AS a 
        JOIN stations AS s ON a.station_id = s.station_id 
        WHERE a.admin_id = ?"; // Use parameterized query to prevent SQL injection

$stmt = $conn->prepare($sql); // Prepare the SQL statement
$stmt->bind_param("i", $admin_id); // Bind the admin_id as an integer
$stmt->execute(); // Execute the statement
$result = $stmt->get_result(); // Get the result set

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    echo json_encode($data);
} else {
    echo json_encode([]); // Return an empty array if no data found
}

$stmt->close(); // Close the prepared statement
$conn->close(); // Close the database connection
?>
