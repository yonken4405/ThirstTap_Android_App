<?php
header('Content-Type: application/json'); // Set the content type to JSON

// Database connection
require 'db.php';

// Count total users
$totalUsersQuery = "SELECT COUNT(*) as total_users FROM user_data";
$totalUsersResult = $conn->query($totalUsersQuery);
$totalUsers = $totalUsersResult->fetch_assoc()['total_users'];

// Calculate total sales of completed orders
$totalSalesQuery = "SELECT SUM(total_price) as total_sales FROM orders WHERE status = 'Completed'";
$totalSalesResult = $conn->query($totalSalesQuery);
$totalSales = $totalSalesResult->fetch_assoc()['total_sales'];

// Count total stations
$totalStationsQuery = "SELECT COUNT(*) as total_stations FROM stations";
$totalStationsResult = $conn->query($totalStationsQuery);
$totalStations = $totalStationsResult->fetch_assoc()['total_stations'];

// Fetch the 10 most recent completed orders
$completedOrdersQuery = "
    SELECT * FROM orders 
    WHERE status = 'Completed' 
    ORDER BY order_date DESC
    LIMIT 10
";
$completedOrdersResult = $conn->query($completedOrdersQuery);
$completedOrders = [];

while ($row = $completedOrdersResult->fetch_assoc()) {
    $completedOrders[] = $row; // Add each order to the array
}

// Initialize sales data arrays for 12 months (January to December)
$salesData = [
    'Completed' => array_fill(0, 12, 0),
    'Pending' => array_fill(0, 12, 0),
    'Ongoing' => array_fill(0, 12, 0),
    'Cancelled' => array_fill(0, 12, 0),
];

// Function to get monthly sales for a given status
function getMonthlySales($conn, $status) {
    $monthlySalesQuery = "
        SELECT MONTH(order_date) as month, SUM(total_price) as total_sales
        FROM orders
        WHERE status = ?
        GROUP BY month
    ";
    $stmt = $conn->prepare($monthlySalesQuery);
    $stmt->bind_param('s', $status);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $monthlySales = array_fill(0, 12, 0); // Initialize monthly sales array for the status

    while ($row = $result->fetch_assoc()) {
        $monthlySales[(int)$row['month'] - 1] = (float)$row['total_sales'];
    }

    return $monthlySales;
}

// Fetch monthly sales for all statuses
$salesData['Completed'] = getMonthlySales($conn, 'Completed');
$salesData['Pending'] = getMonthlySales($conn, 'Pending');
$salesData['Ongoing'] = getMonthlySales($conn, 'Ongoing');
$salesData['Cancelled'] = getMonthlySales($conn, 'Cancelled');

// Close connection
$conn->close();

// Return data as JSON
echo json_encode([
    'total_users' => $totalUsers,
    'total_sales' => number_format($totalSales, 2), // Format sales to 2 decimal places
    'total_stations' => $totalStations,
    'completed_orders' => $completedOrders, // Include the 10 most recent completed orders
    'sales_data' => $salesData // Add sales data for all statuses to the response
]);
?>
