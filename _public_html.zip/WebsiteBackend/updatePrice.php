<?php
session_start();
require 'db.php'; // Adjust based on your database connection setup

// Check if the user is logged in
if (!isset($_SESSION['station_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    exit();
}

// Get the input data
$data = json_decode(file_get_contents('php://input'), true);
$station_id = $_SESSION['station_id'];

// Validate water type
if (!in_array($data['water_type'], ['alkaline', 'purified', 'mineral', 'spring'])) { // Adjusted to match all types
    echo json_encode(["success" => false, "message" => "Invalid water type."]);
    exit();
}

// Retrieve prices from the input data
$price5Gallon = $data['price_round_5gal'] ?? null; // Use null coalescing operator
$priceSlim5Gallon = $data['price_slim_5gal'] ?? null; // Use null coalescing operator
$priceSlim2_5Gallon = $data['price_slim_2_5gal'] ?? null; // Use null coalescing operator
$newContainerPrice = $data['new_container_price'] ?? null; // Use null coalescing operator

// Check if any price data is missing
if ($price5Gallon === null || $priceSlim5Gallon === null || $priceSlim2_5Gallon === null || $newContainerPrice === null) {
    echo json_encode(["success" => false, "message" => "Missing price data."]);
    exit();
}

// Prepare the SQL update statement
$sql = "UPDATE station_prices SET 
            price_5gallon = ?, 
            price_slim_5gallon = ?, 
            price_slim_2_5gallon = ?, 
            new_container_price = ? 
        WHERE station_id = ? AND water_type = ?"; // Include water_type in the WHERE clause
$stmt = $conn->prepare($sql);
$stmt->bind_param("dddids", $price5Gallon, $priceSlim5Gallon, $priceSlim2_5Gallon, $newContainerPrice, $station_id, $data['water_type']); // Add parameters

// Execute the statement and check success
if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update prices: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
