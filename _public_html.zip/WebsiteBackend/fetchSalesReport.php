<?php
session_start(); // Start the session
require 'db.php';

$filter = 'monthly'; // Default filter
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filter = $_POST['date-filter'];
}

// Ensure that the station_id is set in the session
$station_id = isset($_SESSION['station_id']) ? $_SESSION['station_id'] : null;

// Get current date in Philippine Time (PHT)
$timezone = new DateTimeZone('Asia/Manila'); // Define PHT timezone
$dateTime = new DateTime('now', $timezone); // Get the current time in PHT
$currentDatePHT = $dateTime->format('Y-m-d'); // Format as 'Y-m-d'

// Get the start date for 7-day interval (6 days before today)
$startDate = $dateTime->modify('-6 days')->format('Y-m-d'); // 6 days before today

// Prepare SQL query based on the selected filter
$sql = "SELECT orderid, total_price, delivery_date 
        FROM orders 
        WHERE station_id = ? AND status = 'Completed'";

// Add date filter to the SQL query
switch ($filter) {
    case 'today':
        $sql .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = ?";
        break;
    case 'weekly':
        $sql .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) BETWEEN ? AND ?"; // between start date and today
        break;
    case 'monthly':
        $sql .= " AND MONTH(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = MONTH(?) 
                  AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        break;
    case 'yearly':
        $sql .= " AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        break;
}

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameters based on the selected filter
switch ($filter) {
    case 'today':
        $stmt->bind_param("is", $station_id, $currentDatePHT);
        break;
    case 'weekly':
        $stmt->bind_param("iss", $station_id, $startDate, $currentDatePHT); // 3 parameters: station_id, startDate, currentDatePHT
        break;
    case 'monthly':
        $stmt->bind_param("iss", $station_id, $currentDatePHT, $currentDatePHT); // 3 parameters: station_id, currentDatePHT for month, currentDatePHT for year
        break;
    case 'yearly':
        $stmt->bind_param("is", $station_id, $currentDatePHT); // 2 parameters: station_id, currentDatePHT (for year)
        break;
}

// Execute the statement
$stmt->execute();
$result = $stmt->get_result();

$totalSales = 0;
$totalOrders = 0;

while ($row = $result->fetch_assoc()) {
    $totalSales += (float)$row['total_price'];
    $totalOrders++;
}

$stmt->close();
$conn->close();

// Return the total sales and orders as JSON
header('Content-Type: application/json');
echo json_encode(['totalSales' => $totalSales, 'totalOrders' => $totalOrders]);


?>
