<?php
session_start();
require 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['station_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    exit();
}

// Fetch the station ID from the session
$station_id = $_SESSION['station_id'];

// Get the POST data
$data = json_decode(file_get_contents("php://input"), true);

// Prepare the query to update the water type settings based on the is_water_type_enabled column
$query = "UPDATE station_options SET 
    is_water_type_enabled = ?, 
    is_round_5gal_enabled = ?, 
    is_slim_5gal_enabled = ?, 
    is_slim_2_5gal_enabled = ?, 
    is_new_container_enabled = ?, 
    is_exchange_container_enabled = ? 
    WHERE station_id = ? AND water_type = ?";

// Prepare the statement
$stmt = $conn->prepare($query);
$stmt->bind_param("iiiiiiis",
    $data['isWaterTypeEnabled'],        // Enable or disable the water type
    $data['isRound5GalEnabled'],        // Enable or disable round 5-gallon
    $data['isSlim5GalEnabled'],         // Enable or disable slim 5-gallon
    $data['isSlim2_5GalEnabled'],       // Enable or disable slim 2.5-gallon
    $data['isNewContainerEnabled'],     // Enable or disable new container
    $data['isExchangeContainerEnabled'],// Enable or disable exchange container
    $station_id,                        // Station ID from session
    $data['waterType']                  // Water type to update
);

// Execute the statement and check success
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Settings updated successfully.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update settings: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
