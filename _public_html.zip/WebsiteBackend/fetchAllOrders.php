<?php
session_start(); // Start the session
require 'db.php'; // Include your database connection file

// Default filter
$filter = $_POST['date-filter'] ?? 'monthly';
$stationId = $_POST['station-id'] ?? null; // Get the station id if provided
$page = (int)($_POST['page'] ?? 1); // Get current page
$limit = (int)($_POST['limit'] ?? 5); // Get limit

// Get current date in Philippine Time (PHT)
$timezone = new DateTimeZone('Asia/Manila');
$currentDatePHT = (new DateTime('now', $timezone))->format('Y-m-d');

// Prepare base SQL queries
$countSql = "SELECT COUNT(*) as total FROM orders WHERE status = 'Completed'";
$sql = "SELECT o.orderid, o.station_name, o.total_price, o.delivery_date 
        FROM orders o 
        JOIN stations s ON o.station_id = s.station_id 
        WHERE o.status = 'Completed'";

// Initialize parameters and types
$params = [];
$paramTypes = '';

// Add filters based on the selected filter
switch ($filter) {
    case 'today':
        $countSql .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = ?";
        $sql .= " AND DATE(CONVERT_TZ(o.delivery_date, '+00:00', '+08:00')) = ?";
        $params[] = $currentDatePHT;
        $paramTypes .= 's';
        break;
    case 'weekly':
        $startDate = (new DateTime('now', $timezone))->modify('-6 days')->format('Y-m-d');
        $countSql .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) BETWEEN ? AND ?";
        $sql .= " AND DATE(CONVERT_TZ(o.delivery_date, '+00:00', '+08:00')) BETWEEN ? AND ?";
        $params[] = $startDate;
        $params[] = $currentDatePHT;
        $paramTypes .= 'ss';
        break;
    case 'monthly':
        $countSql .= " AND MONTH(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = MONTH(?) 
                       AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        $sql .= " AND MONTH(CONVERT_TZ(o.delivery_date, '+00:00', '+08:00')) = MONTH(?) 
                   AND YEAR(CONVERT_TZ(o.delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        $params[] = $currentDatePHT;
        $params[] = $currentDatePHT;
        $paramTypes .= 'ss';
        break;
    case 'yearly':
        $countSql .= " AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        $sql .= " AND YEAR(CONVERT_TZ(o.delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        $params[] = $currentDatePHT;
        $paramTypes .= 's';
        break;
}

// Add station filter if a station ID is provided
if ($stationId) {
    $countSql .= " AND station_id = ?";
    $sql .= " AND o.station_id = ?";
    $params[] = $stationId;
    $paramTypes .= 'i'; // Assuming station_id is an integer
}

// Prepare and bind parameters for count
$countStmt = $conn->prepare($countSql);
$countStmt->bind_param($paramTypes, ...$params);
$countStmt->execute();
$totalOrders = $countStmt->get_result()->fetch_assoc()['total'];

// Add pagination
$offset = ($page - 1) * $limit; // Calculate offset
$sql .= " LIMIT ?, ?";
$params[] = $offset;
$params[] = $limit;
$paramTypes .= 'ii'; // Always add 'ii' for offset and limit

// Prepare and bind parameters for fetch
$stmt = $conn->prepare($sql);
$stmt->bind_param($paramTypes, ...$params);
$stmt->execute();
$result = $stmt->get_result();

// Fetch completed orders
$completedOrders = [];
$totalSales = (float)($totalSalesResult['total_sales'] ?? 0); // Cast to float to ensure it's numeric

// Calculate total sales for filtered orders without pagination
$totalSalesQuery = "SELECT SUM(total_price) as total_sales FROM orders WHERE status = 'Completed'";

// Reapply the same filters for total sales
switch ($filter) {
    case 'today':
        $totalSalesQuery .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = ?";
        break;
    case 'weekly':
        $totalSalesQuery .= " AND DATE(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) BETWEEN ? AND ?";
        break;
    case 'monthly':
        $totalSalesQuery .= " AND MONTH(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = MONTH(?) 
                              AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        break;
    case 'yearly':
        $totalSalesQuery .= " AND YEAR(CONVERT_TZ(delivery_date, '+00:00', '+08:00')) = YEAR(?)";
        break;
}

// Add station filter if a station ID is provided
if ($stationId) {
    $totalSalesQuery .= " AND station_id = ?";
}

// Prepare and bind parameters for total sales calculation
$totalSalesStmt = $conn->prepare($totalSalesQuery);
$paramTypesSales = '';
$salesParams = [];

// Add parameters based on the filter
switch ($filter) {
    case 'today':
        $salesParams[] = $currentDatePHT;
        $paramTypesSales .= 's';
        break;
    case 'weekly':
        $startDate = (new DateTime('now', $timezone))->modify('-6 days')->format('Y-m-d');
        $salesParams[] = $startDate;
        $salesParams[] = $currentDatePHT;
        $paramTypesSales .= 'ss';
        break;
    case 'monthly':
        $salesParams[] = $currentDatePHT;
        $salesParams[] = $currentDatePHT;
        $paramTypesSales .= 'ss';
        break;
    case 'yearly':
        $salesParams[] = $currentDatePHT;
        $paramTypesSales .= 's';
        break;
}

// Add station filter parameter if exists
if ($stationId) {
    $salesParams[] = $stationId;
    $paramTypesSales .= 'i'; // Assuming station_id is an integer
}

// Bind and execute total sales query
$totalSalesStmt->bind_param($paramTypesSales, ...$salesParams);
$totalSalesStmt->execute();
$totalSalesResult = $totalSalesStmt->get_result()->fetch_assoc();
$totalSales = $totalSalesResult['total_sales'] ?? 0; // Default to 0 if NULL

// Fetch completed orders with pagination
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $formattedDate = date('F j, Y', strtotime($row['delivery_date']));
        $completedOrders[] = [
            'orderid' => $row['orderid'],
            'station_name' => $row['station_name'],
            'total_price' => $row['total_price'],
            'delivery_date' => $formattedDate
        ];
    }
}

// Close statements and connection
$stmt->close();
$countStmt->close();
$totalSalesStmt->close();
$conn->close();

// Return completed orders, total sales, and total orders as JSON
header('Content-Type: application/json');
echo json_encode([
    'completedOrders' => $completedOrders,
    'totalSales' => $totalSales,
    'totalOrders' => $totalOrders
]);
?>
