<?php
header('Content-Type: application/json');

require 'db.php';

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

$user_id = isset($_GET['userId']) ? intval($_GET['userId']) : 0;

if ($user_id > 0) {
    $stmt = $conn->prepare("SELECT userid, name, phone_num, email FROM user_data WHERE userid = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode($user);
    } else {
        echo json_encode(['success' => false, 'message' => 'No user found.']);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid ID.']);
}

$conn->close();
?>
