<?php
header('Content-Type: application/json'); // Set the content type to JSON

// Database connection
require 'db.php';

// Initialize sales data for each status and month (12 months)
$salesData = [
    'Ongoing' => array_fill(0, 12, 0),
    'Pending' => array_fill(0, 12, 0),
    'Completed' => array_fill(0, 12, 0),
    'Cancelled' => array_fill(0, 12, 0),
];

// Query to get total sales by status and month
$salesQuery = "
    SELECT status, MONTH(order_date) as month, SUM(total_price) as total_sales
    FROM orders
    WHERE status IN ('Ongoing', 'Pending', 'Completed', 'Cancelled')
    GROUP BY status, month
";

$salesResult = $conn->query($salesQuery);

// Populate sales data array
while ($row = $salesResult->fetch_assoc()) {
    $status = $row['status'];
    $month = (int)$row['month'] - 1; // Convert month to zero-based index
    $salesData[$status][$month] = (float)$row['total_sales']; // Store sales for each month and status
}

// Close connection
$conn->close();

// Return sales data for the chart
echo json_encode([
    'sales_data' => $salesData
]);
?>
