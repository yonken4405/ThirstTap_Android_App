<?php
require 'db.php'; // Include the database connection

// Get the admin details from the POST request
$admin_id = isset($_POST['admin_id']) ? intval($_POST['admin_id']) : 0;
$station_id = isset($_POST['station_id']) ? intval($_POST['station_id']) : 0;
$admin_name = isset($_POST['adminname']) ? trim($_POST['adminname']) : '';
$contact_number = isset($_POST['contactnum']) ? trim($_POST['contactnum']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';
$role = isset($_POST['role']) ? trim($_POST['role']) : 'Admin'; // Default role if not provided

// Validate the input
if ($admin_id > 0 && !empty($admin_name) && !empty($contact_number) && !empty($email) && !empty($role)) {
    // Prepare the SQL statement to prevent SQL injection
    if (!empty($password)) {
        // Hash the password before saving
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE admins SET station_id = ?, admin_name = ?, contact_number = ?, email = ?, password = ?, role = ? WHERE admin_id = ?");
        $stmt->bind_param("isssssi", $station_id, $admin_name, $contact_number, $email, $hashed_password, $role, $admin_id);
    } else {
        $stmt = $conn->prepare("UPDATE admins SET station_id = ?, admin_name = ?, contact_number = ?, email = ?, role = ? WHERE admin_id = ?");
        $stmt->bind_param("issssi", $station_id, $admin_name, $contact_number, $email, $role, $admin_id);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo json_encode(['success' => 'Admin details updated successfully.']);
    } else {
        echo json_encode(['error' => 'Failed to update admin details.']);
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(['error' => 'Invalid input data.']);
}

// Close the database connection
$conn->close();
?>
