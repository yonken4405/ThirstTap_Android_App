<?php
// Include database connection
include 'db.php'; // Adjust the path as necessary

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the user ID and other user details from the request
    $user_id = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validate the user ID
    if ($user_id > 0) {
        // Prepare the SQL statement
        $stmt = $conn->prepare("UPDATE user_data SET name = ?, phone_num = ?, email = ?, password = ? WHERE userid = ?");
        
        // Hash the password if it is being updated
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Bind parameters
        $stmt->bind_param("ssssi", $name, $contact, $email, $hashed_password, $user_id);

        // Execute the statement
        if ($stmt->execute()) {
            // Check if any rows were affected
            if ($stmt->affected_rows > 0) {
                // User updated successfully
                echo json_encode(['success' => true]);
            } else {
                // User ID not found or no changes made
                echo json_encode(['success' => false, 'message' => 'No changes made or user not found.']);
            }
        } else {
            // Query execution failed
            echo json_encode(['success' => false, 'message' => 'Error executing query.']);
        }

        // Close the statement
        $stmt->close();
    } else {
        // Invalid user ID
        echo json_encode(['success' => false, 'message' => 'Invalid user ID.']);
    }
} else {
    // Not a POST request
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

// Close the database connection
$conn->close();
?>
