<?php
session_start();
require_once 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

$station_id = $_SESSION['station_id'];

// Fetch the station schedule
$stmt = $conn->prepare("SELECT day_of_week, is_closed, opening_time, closing_time FROM station_schedule WHERE station_id = ?");
$stmt->bind_param("i", $station_id);
$stmt->execute();
$result = $stmt->get_result();

$schedule = [];
while ($row = $result->fetch_assoc()) {
    $schedule[$row['day_of_week']] = [
        'closed' => $row['is_closed'],
        'opening' => $row['opening_time'],
        'closing' => $row['closing_time'],
    ];
}

$stmt->close();
$conn->close();

echo json_encode(['success' => true, 'schedule' => $schedule]);
?>
