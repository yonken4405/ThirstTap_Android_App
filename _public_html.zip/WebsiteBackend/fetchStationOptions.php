<?php
session_start();
require 'db.php'; 

// Check if the user is logged in
if (!isset($_SESSION['station_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    exit();
}

// Fetch the station ID from the session
$station_id = $_SESSION['station_id'];

// Prepare and execute the query to fetch all station options for the station
$query = "SELECT * FROM station_options WHERE station_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $station_id);
$stmt->execute();
$result = $stmt->get_result();

// Fetch all rows (representing different water types) into an associative array
$stationOptions = [];
while ($row = $result->fetch_assoc()) {
    $stationOptions[$row['water_type']] = $row; // Group data by water type
}

$stmt->close();
$conn->close();

// Return all station options as JSON
header('Content-Type: application/json');
echo json_encode($stationOptions);
?>
