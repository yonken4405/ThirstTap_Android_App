<?php
require 'db.php'; // Ensure the database connection is included

// Get the admin_id from the request
$admin_id = isset($_GET['admin_id']) ? intval($_GET['admin_id']) : 0;

if ($admin_id > 0) {
    // Prepare the SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT admin_id, station_id, admin_name, contact_number, email, role FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id); // Bind the admin_id as an integer

    // Execute the statement
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        // Check if an admin was found
        if ($result->num_rows > 0) {
            // Fetch the admin details
            $admin = $result->fetch_assoc();
            // Return the admin details as JSON
            echo json_encode($admin);
        } else {
            // Return an error if no admin found
            echo json_encode(['error' => 'No admin found with that ID.']);
        }
    } else {
        echo json_encode(['error' => 'Failed to execute query.']);
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(['error' => 'Invalid admin ID.']);
}

// Close the database connection
$conn->close();
?>
