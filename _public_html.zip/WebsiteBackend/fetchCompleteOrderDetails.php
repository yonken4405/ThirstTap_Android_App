<?php
// Database connection
include 'db.php';

session_start(); // Ensure session is started

// Fetch station_id from session
$station_id = isset($_SESSION['station_id']) ? $_SESSION['station_id'] : null;

if (!$station_id) {
    // If station_id is not available, return an empty response or error
    echo json_encode([]);
    exit;
}

$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Pagination parameters
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Default to page 1
$itemsPerPage = isset($_GET['itemsPerPage']) ? (int)$_GET['itemsPerPage'] : 10; // Default to 10 items per page
$offset = ($page - 1) * $itemsPerPage; // Calculate offset

// Base SQL query with station_id check
$sql = "SELECT o.orderid, o.delivery_date, o.total_price, o.status, 
               u.userid, u.name as customer_name, o.payment_method, o.delivery_address
        FROM orders o 
        JOIN user_data u ON o.userid = u.userid
        WHERE o.station_id = ?"; // Ensure only matching station_id is fetched

// Modify the query based on status and search parameters
$conditions = [];
$params = [$station_id]; // Always bind station_id

if ($status != 'all') {
    $conditions[] = "o.status = ?";
    $params[] = $status;
}

if (!empty($search)) {
    $conditions[] = "(o.orderid LIKE ? OR u.name LIKE ? OR o.payment_method LIKE ? OR o.delivery_address LIKE ? OR o.delivery_date LIKE ?)";
    $searchTerm = '%' . $search . '%';
    $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
}

if (count($conditions) > 0) {
    $sql .= " AND " . implode(" AND ", $conditions);
}

// Order the results by the latest order
$sql .= " ORDER BY o.orderid DESC LIMIT ? OFFSET ?"; // Add LIMIT and OFFSET

// Prepare the statement
$stmt = $conn->prepare($sql);

// Bind parameters dynamically
$params[] = $itemsPerPage; // Bind items per page
$params[] = $offset;       // Bind offset
$stmt->bind_param(str_repeat("s", count($params) - 2) . "ii", ...$params); // Adjust binding types

$stmt->execute();
$result = $stmt->get_result();

$orders = array();

while ($row = $result->fetch_assoc()) {
    $orderId = $row['orderid'];
    
    // Fetch order items
    $itemsQuery = "SELECT water_type, gallon_size, quantity, is_new_container FROM order_items WHERE order_id = ?";
    $itemsStmt = $conn->prepare($itemsQuery);
    $itemsStmt->bind_param("i", $orderId);
    $itemsStmt->execute();
    $itemsResult = $itemsStmt->get_result();
    
    $items = array();
    while ($itemRow = $itemsResult->fetch_assoc()) {
        $items[] = $itemRow;
    }
    
    // Append order details including user and order items
    $orders[] = array(
        'id' => $row['orderid'],
        'userid' => $row['userid'], // Include userid in the response
        'delivery_date' => $row['delivery_date'],
        'total_price' => $row['total_price'],
        'status' => $row['status'],
        'name' => $row['customer_name'],
        'payment_method' => $row['payment_method'],
        'delivery_address' => $row['delivery_address'],
        'items' => $items
    );
}

// Fetch total orders count for pagination
$countSql = "SELECT COUNT(*) as total FROM orders o WHERE o.station_id = ?";
$countStmt = $conn->prepare($countSql);
$countStmt->bind_param("s", $station_id);
$countStmt->execute();
$countStmt->store_result(); // Store the result to get total count
$countStmt->bind_result($totalOrders);
$countStmt->fetch(); // Fetch the total count

echo json_encode([
    'orders' => $orders,
    'totalOrders' => $totalOrders,
    'currentPage' => $page,
    'itemsPerPage' => $itemsPerPage,
]);

$conn->close();

?>
