<?php
// changeCredentials.php
session_start();
include 'db.php'; // Your database connection
// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in.']);
    exit;
}

// Get admin ID and station ID from session
$admin_id = $_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $newEmail = $data['new_email'];
    $currentPassword = $data['current_password'];
    $newPassword = $data['new_password'];

    // Fetch current admin data for verification
    $stmt = $conn->prepare("SELECT password, email FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $_SESSION['admin_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    // Verify current password
    if (password_verify($currentPassword, $admin['password'])) {
        // Update email and password
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        $updateStmt = $conn->prepare("UPDATE admins SET email = ?, password = ? WHERE admin_id = ?");
        $updateStmt->bind_param("ssi", $newEmail, $hashedPassword, $_SESSION['admin_id']);
        if ($updateStmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Credentials updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update credentials']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
    }
}
?>
