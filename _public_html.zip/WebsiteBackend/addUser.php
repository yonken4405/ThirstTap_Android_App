<?php
// Include database connection
include 'db.php'; // Adjust the path as necessary

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get user details from the request
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $contact = isset($_POST['contact']) ? $_POST['contact'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Validate input fields
    if (!empty($name) && !empty($contact) && !empty($email) && !empty($password)) {
        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO user_data (name, phone_num, email, password) VALUES (?, ?, ?, ?)");

        // Hash the password for secure storage
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Bind parameters
        $stmt->bind_param("ssss", $name, $contact, $email, $hashed_password);

        // Execute the statement
        if ($stmt->execute()) {
            // User added successfully
            echo json_encode(['success' => true, 'message' => 'User added successfully.']);
        } else {
            // Query execution failed
            echo json_encode(['success' => false, 'message' => 'Error executing query.']);
        }

        // Close the statement
        $stmt->close();
    } else {
        // Invalid input
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    }
} else {
    // Not a POST request
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}

// Close the database connection
$conn->close();
?>
