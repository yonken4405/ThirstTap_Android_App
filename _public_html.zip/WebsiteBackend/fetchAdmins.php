<?php
require 'db.php'; // Include your database connection file

// Get the current page and items per page from the request
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$itemsPerPage = 10; // Adjust this as needed
$offset = ($page - 1) * $itemsPerPage;

// Count total admins for pagination
$totalQuery = "SELECT COUNT(*) as total FROM admins";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalAdmins = $totalRow['total'];
$totalPages = ceil($totalAdmins / $itemsPerPage);

// Fetching admin details with pagination
$query = "SELECT admin_id, admin_name, contact_number, email, station_name, role FROM admins LIMIT $offset, $itemsPerPage";

$result = $conn->query($query);

// Check for errors in the SQL execution
if (!$result) {
    die('Query error: ' . $conn->error);
}

// Prepare an array to hold the admin data
$admins = [];

if ($result->num_rows > 0) {
    // Fetch all results into the $admins array
    while ($row = $result->fetch_assoc()) {
        $admins[] = $row;
    }
}

// Close the database connection
$conn->close();

// Return the admin data and total pages as a JSON object
header('Content-Type: application/json'); // Set header for JSON response
echo json_encode(['admins' => $admins, 'totalPages' => $totalPages]);
?>
