<?php
ini_set('error_log', __DIR__ . '/my_custom_error_log.log');
// Include your database connection here
require_once 'db.php';  // Ensure you have the right path to your db.php file

session_start(); // Ensure session is started

// Fetch station_id from session
$stationId = isset($_SESSION['station_id']) ? $_SESSION['station_id'] : null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if order_ids, status, and userid are set in the POST request
    if (isset($_POST['order_ids'], $_POST['status'], $_POST['userid'])) {
        $orderIds = $_POST['order_ids']; // This should be an array of order IDs
        $status = $_POST['status'];
        $userId = $_POST['userid'];

        // Sanitize inputs to avoid SQL injection
        $status = filter_var($status, FILTER_SANITIZE_STRING);
        $userId = filter_var($userId, FILTER_SANITIZE_NUMBER_INT);

        // Validate the status
        $validStatuses = ['Pending', 'Ongoing', 'Completed', 'Cancelled'];
        if (!in_array($status, $validStatuses)) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid status']);
            exit;
        }

        // Prepare the SQL statement to update the order status
        $stmt = $conn->prepare('UPDATE orders SET status = ? WHERE orderid = ?');
        if ($stmt) {
            // Prepare the bulk insertion SQL statement for notifications
            $notifSql = 'INSERT INTO notifications (orderid, userid, station_id, message) VALUES ';
            $notifValues = [];
            $notifParams = [];

            // Variable to track if notifications were sent
            $notificationsSent = false;

            // Loop through each order ID
            foreach ($orderIds as $orderId) {
                $orderId = filter_var($orderId, FILTER_SANITIZE_NUMBER_INT);

                // Validate the order ID
                if (!filter_var($orderId, FILTER_VALIDATE_INT) || $orderId <= 0) {
                    echo json_encode(['status' => 'error', 'message' => 'Invalid order ID: ' . $orderId]);
                    exit;
                }

                $stmt->bind_param('si', $status, $orderId);

                // Execute the statement and check for success
                if (!$stmt->execute()) {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to update order status for order ID ' . $orderId . ': ' . $stmt->error]);
                    exit;
                }

                // Prepare the message for the notification
                $message = "";
                switch ($status) {
                    case 'Ongoing':
                        $message = "Your order #$orderId has been accepted and is now ongoing.";
                        break;
                    case 'Cancelled':
                        $message = "Your order #$orderId has been cancelled.";
                        break;
                    case 'Completed':
                        $message = "Your order #$orderId has been completed.";
                        break;
                    case 'Pending':
                        $message = "Your order #$orderId is still pending.";
                        break;
                }

                // Add values to the bulk insertion array
                $notifValues[] = "(?, ?, ?, ?)";
                $notifParams[] = $orderId;
                $notifParams[] = $userId;
                $notifParams[] = $stationId;
                $notifParams[] = $message;

                // Get the user's FCM token
                $fcmToken = getFcmToken($userId); // Implemented function

                // Debug log for FCM Token
                error_log("FCM Token for user ID $userId: " . $fcmToken);

                if ($fcmToken) {
                    // Debug log before sending the notification
                    error_log("Sending notification to FCM Token: " . $fcmToken);
                    // Send the FCM notification
                    $result = sendFcmNotification($fcmToken, $message);
                    error_log("FCM Response: " . $result); // Log FCM response

                    // Mark that a notification was sent
                    $notificationsSent = true;
                } else {
                    // Log warning if the FCM token is not found
                    error_log("FCM Token not found for user ID: " . $userId); // Log if token is null
                }
            }

            // If there are notifications to insert, prepare the bulk insertion statement
            if (!empty($notifValues)) {
                $notifSql .= implode(', ', $notifValues);
                $notifStmt = $conn->prepare($notifSql);
                if ($notifStmt) {
                    // Bind the parameters for the bulk insert
                    $types = str_repeat('iiis', count($notifValues)); // Create a string of types for binding
                    $notifStmt->bind_param($types, ...$notifParams);

                    // Execute the bulk insert statement
                    if (!$notifStmt->execute()) {
                        echo json_encode(['status' => 'error', 'message' => 'Failed to insert notifications: ' . $notifStmt->error]);
                        exit;
                    }
                    $notifStmt->close();
                } else {
                    echo json_encode(['status' => 'error', 'message' => 'Failed to prepare notification bulk SQL statement']);
                    exit;
                }
            }

            // Change the success response logic
            if ($notificationsSent) {
                // Send a summary notification for all updated orders
                $summaryMessage = "Your orders have been updated: " . implode(", ", array_map(function($id) use ($status) {
                    return "Order #$id is now $status";
                }, $orderIds));

                if ($fcmToken) {
                    sendFcmNotification($fcmToken, $summaryMessage);
                }

                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'No notifications were sent.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to prepare SQL statement']);
        }

        // Close the statement
        $stmt->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Missing order IDs, status, station ID, or user ID']);
    }

    // Close the connection
    $conn->close();
} else {
    // Handle the case where the request method is not POST
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}

// Function to send FCM Notification
function sendFcmNotification($token, $message) {
    $url = 'https://fcm.googleapis.com/v1/projects/thirsttap-caca0/messages:send';
    $serviceAccount = 'thirsttap-caca0-firebase-adminsdk-y55zg-e89ef15e36.json'; // Update this path 

    // Load the service account credentials
    $credentials = json_decode(file_get_contents($serviceAccount), true);

    // Create the JWT token
    $header = json_encode(['alg' => 'RS256', 'typ' => 'JWT']);
    $claim = json_encode([
        'iss' => $credentials['client_email'],
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => 'https://oauth2.googleapis.com/token',
        'exp' => time() + 3600, // 1 hour expiration
        'iat' => time() // Added issued at time (iat) to resolve the error
    ]);
    $headerEncoded = base64_encode($header);
    $claimEncoded = base64_encode($claim);
    $signature = '';
    $key = openssl_pkey_get_private($credentials['private_key']);
    openssl_sign("$headerEncoded.$claimEncoded", $signature, $key, OPENSSL_ALGO_SHA256);
    $jwt = "$headerEncoded.$claimEncoded." . base64_encode($signature);

    // Request to get access token
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt,
    ]));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
    ]);
    
    $response = curl_exec($ch);
    
    // Check for cURL errors
    if ($response === false) {
        error_log("cURL error: " . curl_error($ch));
        return; // Exit if the request fails
    }
    
    curl_close($ch);
    
    // Decode the response
    $responseData = json_decode($response, true);
    
    // Log the entire response for debugging
    error_log("Response from token request: " . print_r($responseData, true));
    
    // Check if access_token is present
    if (!isset($responseData['access_token'])) {
        error_log("Access token not found in the response: " . print_r($responseData, true));
        return; // Exit if access token is not found
    }
    
    $accessToken = $responseData['access_token'];
    
    // Prepare the FCM message
    $notification = [
        'message' => [
            'token' => $token,
            'notification' => [
                'title' => 'Order Update',
                'body' => $message,
            ],
            'data' => [
                'additionalData' => 'Your additional data here', // Optional additional data
            ],
        ],
    ];

    // Send the FCM request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification));
    
    $result = curl_exec($ch);
    
    // Check for cURL errors
    if ($result === false) {
        error_log("cURL error sending FCM notification: " . curl_error($ch));
    }
    
    curl_close($ch);
    
    // Log the result of the FCM request
    error_log("FCM Notification Result: " . $result);
    
    return $result;
}

// Function to get the FCM token from the database
function getFcmToken($userId) {
    global $conn; // Use the global $conn variable to access the database

    $stmt = $conn->prepare('SELECT fcm_token FROM user_data WHERE userid = ?');
    $stmt->bind_param('i', $userId);
    
    if ($stmt->execute()) {
        $stmt->bind_result($fcmToken);
        $stmt->fetch();
        $stmt->close();
        return $fcmToken;
    } else {
        error_log("Failed to fetch FCM token for user ID $userId: " . $stmt->error);
        return null; // Return null if the query fails
    }
}
?>
