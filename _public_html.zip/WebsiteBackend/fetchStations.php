<?php
require 'db.php'; // Make sure to include your database connection file

// Set default values for pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10; // Default to 10 stations per page
$offset = ($page - 1) * $limit; // Calculate the offset for the SQL query

// Fetch total number of stations for pagination
$totalStationsQuery = "SELECT COUNT(*) AS total FROM stations";
$totalResult = $conn->query($totalStationsQuery);
$totalStations = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalStations / $limit); // Calculate total pages

// Fetch stations from the database with pagination
$sql = "SELECT station_id, station_address, name, latitude, longitude, contact_number, email FROM stations LIMIT $offset, $limit";
$result = $conn->query($sql);

$stations = [];

if ($result->num_rows > 0) {
    // Fetch all stations as an associative array
    while ($row = $result->fetch_assoc()) {
        $stations[] = $row; // Add each station to the array
    }
}

// Return the stations and total pages as JSON
header('Content-Type: application/json');
echo json_encode(['stations' => $stations, 'totalPages' => $totalPages]);

$conn->close(); // Close the database connection
?>
