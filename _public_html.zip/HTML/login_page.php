<?php
// Include your database connection file
require 'session_data.php'; // Include session data handling
require '../WebsiteBackend/db.php';



// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT * FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        // Verify password
        if (password_verify($password, $admin['password'])) {
            // Set session data using the function from session_data.php
            setAdminSession($admin);
        
            // Redirect based on role
            if ($admin['role'] === 'Admin') {
                header("Location: dashboard.html"); // Admin dashboard
            } elseif ($admin['role'] === 'Super Admin') {
                header("Location: SuperAdminHTML/super admin dashboard.html"); // Super admin dashboard
            } else {
                header("Location: dashboard.html"); // Default redirection
            }
            exit();
        
        } else {
            // Wrong password
            header("Location: login_page.php?error=Incorrect password");
            exit();
        }
    } else {
        // Email not found
        header("Location: login_page.php?error=Email not registered");
        exit();
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - ThirstTap</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
     <!-- Font Awesome Icons -->
     <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: 'Poppins', Arial, sans-serif;
            background-image: url('assets/login_bg.png'); /* Add your background image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: flex-start; /* Align the container to the left */
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin: 0;
            height: 100vh;
            max-width: 35%;
            padding: 20px 60px 20px 60px;
            background-color: rgba(40, 190, 230, 0.40); /* Slightly transparent blue */
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

            .logo p {
                color: #FFFFFF;
                font-weight: 600;
                font-size: 15px;
            }

           
        }

        .container p{
            color: #FFFFFF;
            font-weight: 600;
            font-size: 28px;
            margin-bottom:30px;

        }

        .logo {
            text-align: center;
            margin-bottom:40px;
            border-bottom: 1px solid white;
            width: 100%;

        }
       
        .btn-primary {
            
            background-color: #7ACDE7;
            border: none;
            border-radius: 20px;
            font-weight: 600;
            font-size: 16px;
            height: 45px;
            margin-top: 50px;
        }
        .btn-primary:hover {
            background-color: #65ACC2;
        }
        .error {
            color: red;
            margin-top: 10px;
            text-align: center;
        }



        form .form-group{
            margin-bottom: 30px;
            width: 100%;
        }

        
       form{
          width: 100%;
           padding: 0 40px 0 40px;
        }

        label{
            color: white;
            font-weight: 600;
            font-size: 14px;
        }

        .position-relative {
            margin-bottom: 30px; /* Space below the input */
        }

        .position-absolute {
            width: 20px; /* Adjust based on your icon size */
            height: auto; /* Maintain aspect ratio */
            pointer-events: none; /* So clicks go to the input */
        }

        .toggle-password{
            pointer-events: auto; /* Allow clicks to be detected */
            cursor: pointer; /* Show pointer cursor */
        }
        
        input{
            height: 45px  !important;
            padding: 10px 40px 10px 10px !important;
            width: 100%;
            border-radius: 12px !important;
       

        }

        .form-control{
            background-color: #FFFFFF !important;
            border: 1px solid #FFFFFF !important;
        }

        
        .logo h2 {
    
            font-family: 'Montserrat', sans-serif;
            text-align: center;
          
    
        }

        .logo h2 .thirst {
            color: #0033FF; 
            font-weight: 700; 
            font-size: 60px; 
        }

        .logo h2 .tap {
            color: #FFFFFF; 
            font-size: 60px; 
        }

        .logo h2 .admin {
            color: #ffffff; 
            font-style: italic; 
            font-size: 40px; 
            font-weight: normal; 
            margin-left: 160px;
            position: relative; 
            top: -5px;
        }



    
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
        <h2><span class="thirst">Thirst</span><span class="tap">Tap</span><br><span class="admin">Admin</span></h2>
            <p><i>Ready to deliver more water?</i></p>
        </div>
        <p>Sign in to your account</p>
        <form method="POST" action="" onsubmit="return validateForm()">
            <div class="form-group position-relative">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
                <img src="assets/email_ic.png" class="position-absolute" alt="Email Icon" style="right: 10px; top: 60%;">
            </div>
            <div class="form-group position-relative">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
                <img src="assets/password_slash_ic.png" class="position-absolute toggle-password" alt="Password Icon" style="right: 10px; top: 60%;">
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
            <div class="error" id="formError">
                <?php
                if (isset($_GET['error'])) {
                    echo htmlspecialchars($_GET['error']);
                }
                ?>
            </div>
        </form>

    </div>
   
    <script>
        const togglePassword = document.querySelector('.toggle-password');
        const passwordField = document.getElementById('password');

        togglePassword.addEventListener('click', function () {
            const isPasswordVisible = passwordField.type === 'text';

            // Toggle the type attribute
            passwordField.type = isPasswordVisible ? 'password' : 'text';

            // Toggle the icon
            togglePassword.src = isPasswordVisible 
                ? 'assets/password_slash_ic.png' // Show eye-slash icon when password is hidden
                : 'assets/eye_ic.png';       // Show regular eye icon when password is visible
        });

        function validateForm() {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('formError');

            // Clear previous error message
            errorDiv.textContent = '';

            // Check if fields are empty
            if (!email) {
                errorDiv.textContent = 'Email is required.';
                return false;
            }
            if (!password) {
                errorDiv.textContent = 'Password is required.';
                return false;
            }
            return true; // Proceed with form submission
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


