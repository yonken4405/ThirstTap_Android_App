<?php
session_start(); // Start the session

function setAdminSession($admin) {
    $_SESSION['admin_id'] = $admin['admin_id'];
    $_SESSION['station_id'] = $admin['station_id'];
    $_SESSION['role'] = $admin['role'];
    $_SESSION['email'] = $admin['email'];
    $_SESSION['name'] = $admin['admin_name']; // Example additional field
    $_SESSION['contact_number'] = $admin['contact_number']; // Example additional field
}

?>
